
# 🚀 Instrucciones de Configuración - Summit Origins

## ✅ Tu tienda web está lista y funcionando

La tienda web "Summit Origins - Magnesia Premium para Escalada" ha sido creada con éxito y está corriendo localmente en `http://localhost:8080`.

## 🎯 Próximos Pasos para Ponerla en Producción

### 1. CONFIGURAR PAGOS (CRÍTICO)

#### 📱 Stripe Payment Links
1. Ve a [dashboard.stripe.com](https://dashboard.stripe.com)
2. Crea 3 Payment Links:
   - **1 unidad**: $199 MXN
   - **2 unidades**: $360 MXN  
   - **3 unidades**: $510 MXN
3. Copia las URLs y pégalas en `data/config.json`:
```json
"stripeLink": "https://buy.stripe.com/TU_LINK_REAL_AQUI"
```

#### 💳 MercadoPago
1. Ve a [mercadopago.com.mx](https://mercadopago.com.mx)
2. Crea botones de pago para cada cantidad
3. Copia las URLs en `data/config.json`:
```json
"mercadoPagoLink": "https://www.mercadopago.com.mx/TU_LINK_AQUI"
```

### 2. CONFIGURAR WHATSAPP

En `data/config.json`, cambia:
```json
"contact": {
  "whatsapp": {
    "number": "TU_NUMERO_AQUI",
    "message": "Hola! Me interesa la magnesia Summit Origins"
  }
}
```

### 3. CONFIGURAR GOOGLE ANALYTICS

1. Crea una cuenta en [analytics.google.com](https://analytics.google.com)
2. Configura una propiedad GA4
3. Copia tu Measurement ID
4. En `data/config.json`:
```json
"analytics": {
  "googleAnalyticsId": "G-TU_ID_AQUI"
}
```

### 4. DESPLEGAR EN GITHUB PAGES (GRATUITO)

#### Opción A: Interfaz Web de GitHub
1. Ve a [github.com](https://github.com) e inicia sesión
2. Clic en "New repository"
3. Nombre: `magnesia-store`
4. Marca "Public"
5. Clic en "Create repository"
6. En el repo nuevo, clic en "uploading an existing file"
7. Arrastra TODOS los archivos de `/home/ubuntu/magnesia_store/`
8. Commit message: "Tienda Summit Origins lista"
9. Clic en "Commit changes"

#### Activar GitHub Pages:
1. En tu repositorio, ve a **Settings > Pages**
2. En "Source": selecciona **"Deploy from a branch"**
3. En "Branch": selecciona **"main"**
4. En "Folder": selecciona **"/ (root)"**
5. Clic en "Save"

**🎉 Tu sitio estará disponible en:**
```
https://tu-usuario.github.io/magnesia-store
```

#### Opción B: Git Command Line
```bash
git clone https://github.com/tu-usuario/magnesia-store.git
cd magnesia-store
cp -r /home/ubuntu/magnesia_store/* .
git add .
git commit -m "Tienda Summit Origins lista"
git push origin main
```

## 🔧 Ediciones Rápidas

### Cambiar Precios
Edita `data/config.json`:
```json
{
  "quantity": 1,
  "price": 199,        // <- Cambia aquí
  "shipping": 89,      // <- Y aquí
  "popular": false
}
```

### Agregar/Cambiar Testimonios
En `data/config.json`:
```json
"testimonials": [
  {
    "name": "Nuevo Cliente",
    "rating": 5,
    "text": "¡Excelente magnesia!",
    "level": "Boulder V8"
  }
]
```

### Cambiar Colores de la Marca
En `assets/css/styles.css`:
```css
:root {
    --primary-color: #2563eb;    /* Color principal */
    --accent-color: #f59e0b;     /* Color de acento */
}
```

## 📱 Funcionalidades Incluidas

✅ **Responsive Design** - Se ve perfecto en móvil y desktop
✅ **Sistema de Precios Flexible** - Editable desde JSON
✅ **Integración de Pagos** - Stripe y MercadoPago listos
✅ **WhatsApp Direct** - Contacto inmediato con clientes
✅ **SEO Optimizado** - Meta tags y estructura semántica
✅ **Analytics Ready** - Google Analytics 4 configurado
✅ **Políticas Legales** - Envíos, devoluciones y privacidad
✅ **Loading Rápido** - Optimizado para velocidad
✅ **Imágenes Profesionales** - Producto y lifestyle incluidas
✅ **FAQ Interactivo** - Preguntas frecuentes desplegables

## 🎨 Personalización Avanzada

### Cambiar Imágenes del Producto
1. Sube tus imágenes a [imgbb.com](https://imgbb.com) o similar
2. En `index.html`, busca las URLs de imágenes:
```html
<img src="https://i.ytimg.com/vi/a5T1MiQmgKQ/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLDhK_aO9uBtSJAd-reDccDbp3DHeA" alt="...">
```
3. Reemplaza con tus nuevas URLs

### Dominio Personalizado (Opcional)
1. Compra un dominio (ej: summitorigins.com)
2. En GitHub Pages settings, agrega tu dominio personalizado
3. Configura DNS según instrucciones de GitHub

## 🔍 Testing y Verificación

### Lista de Verificación Pre-Launch:
- [ ] Precios correctos en config.json
- [ ] Enlaces de pago funcionando
- [ ] Número de WhatsApp correcto
- [ ] Google Analytics configurado
- [ ] Todas las páginas cargan sin errores
- [ ] Responsive en móvil probado
- [ ] Formularios de contacto funcionando

### Herramientas de Testing:
- **PageSpeed Insights**: Velocidad de carga
- **Mobile-Friendly Test**: Compatibilidad móvil
- **JSON Validator**: Verificar sintaxis del config

## 📊 Monitoreo Post-Launch

1. **Google Analytics**: Tráfico y conversiones
2. **Search Console**: SEO y indexación
3. **Uptime Monitoring**: Disponibilidad del sitio
4. **Enlaces de Pago**: Verificar que funcionen periódicamente

## 🚨 Solución de Problemas Comunes

### "Los precios no se cargan"
- Verifica sintaxis JSON en config.json
- Usa [jsonlint.com](https://jsonlint.com) para validar

### "Enlaces de pago no funcionan"
- Confirma que los links de Stripe/MP estén activos
- Prueba los links directamente en el navegador

### "El sitio no carga en GitHub Pages"
- Espera 5-10 minutos después de activar Pages
- Verifica que todos los archivos estén en el repositorio
- Revisa Settings > Pages para mensajes de error

## 💬 Soporte

Si necesitas ayuda:
1. Revisa este archivo completo
2. Consulta el README.md principal
3. Verifica la consola del navegador (F12) para errores
4. Usa las herramientas de desarrollo para debug

## 🎉 ¡Felicidades!

Has creado una tienda web profesional y completa. Con estos pasos tu negocio estará online en menos de 30 minutos.

**Próximos pasos recomendados:**
1. Configurar pagos ⚡ (prioritario)
2. Desplegar en GitHub Pages 🚀
3. Compartir en redes sociales 📱
4. Optimizar para búsquedas 🔍

---
**Tienda creada con 💙 para escaladores exigentes**
